closeit Version 1.0
============
A jquery plugin created by samworks.in free to use both personal and commercial

Installation Instructions;

Add jquery library and add jquery.closeit.js inside js folder
and add jquery.closeit.css inside css folder with mask.svg

Now you can convert any selector to close icon by adding 

$(selector).closeit(); inside document ready function in your page. 

<<<<<<< HEAD
==============================
Plugin created by samworks.in
==============================
=======
JS Fiddle url:

http://jsfiddle.net/satheeaseelan/C5R2L/

==============================
Plugin created by samworks.in
==============================
>>>>>>> FETCH_HEAD
